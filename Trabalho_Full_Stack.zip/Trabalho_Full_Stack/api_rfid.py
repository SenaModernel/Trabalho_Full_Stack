from flask import Flask, jsonify, request
import psycopg2

app = Flask(__name__)

# Conecta ao Postgre
conn = psycopg2.connect(
    host="localhost",  
    database="Controle da Tecnologia",  
    user="postgres",  
    password="Atitus@2024"                                                                                                          
)

# Funcao que procura o RFID no Postgre
def buscar_usuario_por_rfid(rfid):
    with conn.cursor() as cursor:
        cursor.execute("SELECT nome FROM usuarios WHERE rfid = %s", (rfid,))
        usuario = cursor.fetchone()
        return usuario[0] if usuario else None

@app.route('/api/acesso', methods=['GET'])
def verificarAcesso():
    rfid = request.args.get('rfid')
    if not rfid: 
        return jsonify({'error': 'RFID não fornecido'}), 400

    usuario = buscar_usuario_por_rfid(rfid)
    
    if usuario:
        return jsonify({'mensagem': 'Acesso permitido', 'usuario': usuario}), 200
    else:
        return jsonify({'mensagem': 'Acesso negado'}), 403

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5433)